# Roger Gaulke
# Jon Camarillo
# 17 May 2020

# SUMMARY:  Our crypto-program is designed to find the prime factors of any given semiprime number that is < 2^64.
# The inputs are read from a text file saved as Semiprimes.txt.
# Each factors of each semiprime are then written into their own individual text file saved as Factors_XXXXXXXX.txt.
# The save file containing the factors are uniquely identified using eight digits - Factors_00000001.txt would be the first file to be written.
# The algorithm is based on RSA encryption.
# First, we check to see if the semiprime can be factored into a 2, a prime number, and another prime number.
# If no factors were found that fit that criteria, then we process the semiprime via a mathematical method that utilizes the fact
# that prime factors exist and that they can be obtained by stepping through a function in increments of 1 and determining
# if a perfect square exists.  The presence of a perfect square ensures factors were found.  If these factors are both prime,
# they will be written to a file.  Otherwise, incrementing the function by one continues.  The process can be visualized as
# a middle-out process.  We start from the middle, and work outwards.  That is, we check for factors whose difference is small, and
# the more times increments occur, the greater the difference between the two factors grow.  The method used is in contrast to an outward-in method,
# left-to-right method, right-to-left, and others.

# Bansal, Shubham. “Check Whether a Number Is Semiprime or Not - GeeksforGeeks.” www.geeksforgeeks.org/check-whether-number-semiprime-not/.
# https://www.geeksforgeeks.org/check-whether-number-semiprime-not/


# import maths for mathematical operations (square root, ceiling, etc.)
import math
import os

# We use the time to track program execution length.
import time

# We use concurrent.future.ProcessPoolExecutor() to use the python multiprocessing module.
import concurrent.futures

# Takes in an integer and checks to see if it is prime.
# Used on factors that were found to make sure both are prime.
def isPrime(n):

    # Ensure smaller inputs are taken into account.
    if (n <= 1):
        return False
    if (n <= 3):
        return True

    # This is checked so that we can skip
    # middle five numbers in below loop
    if (n % 2 == 0 or n % 3 == 0):
        return False

    i = 5
    while (i * i <= n):
        if (n % i == 0 or n % (i + 2) == 0):
            return False
        i = i + 6

    return True

# function to read input from file
def readInput(filename):
    # open file with read access
    file = open(filename, 'r')
    # split file data by lines
    lines = file.read().splitlines()
    # convert all lines into integer n
    ns = []
    for n in lines:
        ns.append(int(n))

    # return all n's from file
    return ns


# function to write into output file
def output(filename, p, q):
    # get absolute path to file
    script_dir = os.path.split('_file_')[0]
    rel_path = "Outputs/" + str(filename)
    abs_file_path = os.path.join(script_dir, rel_path)

    # open file
    file_out = open(abs_file_path, 'a+')

    # write all information in file
    file_out.write(str(p) + '\n')
    file_out.write(str(q) + '\n')

    # close output file
    file_out.close()


# function to check if given number is perfect square
counter = 0
def isPerfectSquare(x):

    # find sqrt of number
    sr = math.sqrt(x)

    # check if floor of sqrt and sqrt are equal

    if (sr - math.floor(sr)) == 0:
        return True

    # otherwise
    else:
        return False

# finding prime factors by RSA algorithm
num = 0
def RSA(n):
    # print("Process START: pid [{}]".format(os.getpid()))

    # get ceil value of sqrt(N)
    a = math.ceil(math.sqrt(n))

    # if n is divisible by 2
    # then p = 2 and q = other prime factor.
    if n % 2 == 0:
        p = 2
        q = n/2

        r = isPrime(p)
        s = isPrime(q)

        if r == True and s == True:
            return p, q

    # keep increasing value of "a" till
    # a*a-n becomes a perfect square

    while True:

        # stop if perfect square
        if isPerfectSquare(a * a - n) == True:
            # find B
            b = math.sqrt(a * a - n)

            # find values of p and q
            p = a + b
            q = a - b

            # return both primes
            r = isPrime(p)
            s = isPrime(q)
            if r == True and s == True:
                return p, q
            else:
                a += 1
                continue

        # if isPerfectSquare(a * a - n) == False
        # increment a by 1.
        a += 1

# main function implementation
def main():
    fileNum = 0
    fileName = "Semiprimes.txt"
    print("Reading inputs from " + fileName + "...")

    # n = list[] of numbers in the read file
    n = readInput(fileName)
    print("Read successful!\n")

    # iterate over all n's
    print("Factoring and writing factors to file....\n")

    # Multiprocessing with concurrent.futures
    with concurrent.futures.ProcessPoolExecutor() as executor:

        # Process numbers one-by-one in RSA.
        # Store factors p and q into results.
        results = executor.map(RSA, n)

        # Write factors into files and in order corresponding to Semiprimes.txt
        for a, b, in results:
            fileNum += 1
            filename = "Factors_" + "{:08d}".format(fileNum) + ".txt"
            output(filename, a, b)
            print("\n----------Write Success! " +
                  str(fileNum) + "/" + str(len(n)) +
                  " ----------")

    print("\nDone!\n")

# it starts main function
if __name__ == '__main__':
    tic = time.perf_counter()
    print(f"----------------------------------------\n"
          f"Program START time: {tic:0.4f} seconds\n"
          f"----------------------------------------")

    main()

    toc = time.perf_counter()

    print(f"----------------------------------------\n"
          f"Program END time: {toc - tic:0.4f} seconds\n"
          f"----------------------------------------\n")
